#!/usr/bin/env python3

import sys, os, json
from datetime import datetime, date
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QComboBox, QStackedWidget,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
    QTabWidget, QFormLayout, QTextEdit, QSpinBox, QDoubleSpinBox,
    QDateEdit, QTimeEdit, QGroupBox, QSplitter, QFrame, QDialog,
    QDialogButtonBox, QScrollArea, QGridLayout,
    QProgressBar, QGraphicsDropShadowEffect
)
from PyQt5.QtCore import Qt, QDate, QTime, QTimer, QPropertyAnimation, QEasingCurve, QPoint
from PyQt5.QtGui import QColor, QFont

sys.path.insert(0, os.path.dirname(__file__))
import db
from algorithms import (
    search_medical_history, Appointment, greedy_schedule_optimization,
    find_conflicts, Medicament, optimize_prescriptions_dp,
    PatientHashTable, AVLTree, AppointmentHeap
)

# ============================================================
# THEME MEDICAL PROFESSIONNEL
# ============================================================
C_BG = "#F3F7FB"
C_WHITE = "#ffffff"
C_PRIMARY = "#0F6CBD"
C_PRIMARY_DARK = "#0B5DA8"
C_PRIMARY_LIGHT = "#EBF4FF"
C_SUCCESS = "#10B981"
C_SUCCESS_LIGHT = "#D1FAE5"
C_DANGER = "#EF4444"
C_DANGER_LIGHT = "#FEE2E2"
C_WARNING = "#F59E0B"
C_WARNING_LIGHT = "#FEF3C7"
C_TEXT = "#1F2937"
C_TEXT_SEC = "#6B7280"
C_TEXT_LIGHT = "#9CA3AF"
C_BORDER = "#E5E7EB"
C_BORDER_FOCUS = "#0F6CBD"

STYLE_BASE = f"""
QMainWindow {{ background-color: {C_BG}; }}
QWidget {{ font-family: 'Segoe UI', -apple-system, Arial, sans-serif; font-size: 13px; color: {C_TEXT}; }}
QPushButton {{
    background-color: {C_PRIMARY}; color: white; border: none;
    padding: 10px 24px; border-radius: 12px; font-weight: 600; font-size: 13px;
    min-height: 20px;
}}
QPushButton:hover {{ background-color: {C_PRIMARY_DARK}; }}
QPushButton:pressed {{ background-color: {C_PRIMARY_DARK}; }}
QPushButton:disabled {{ background-color: {C_BORDER}; color: {C_TEXT_LIGHT}; }}
QPushButton#btnDanger {{ background-color: {C_DANGER}; }}
QPushButton#btnDanger:hover {{ background-color: #DC2626; }}
QPushButton#btnOutline {{
    background-color: {C_WHITE}; color: {C_PRIMARY};
    border: 2px solid {C_BORDER};
}}
QPushButton#btnOutline:hover {{
    background-color: {C_PRIMARY_LIGHT}; border-color: {C_PRIMARY};
}}
QPushButton#btnSuccess {{ background-color: {C_SUCCESS}; }}
QPushButton#btnSuccess:hover {{ background-color: #059669; }}
QPushButton#btnWarning {{ background-color: {C_WARNING}; color: white; }}
QPushButton#btnWarning:hover {{ background-color: #D97706; }}
QLineEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateEdit, QTimeEdit {{
    padding: 10px 14px; border: 2px solid {C_BORDER}; border-radius: 12px;
    background: {C_WHITE}; font-size: 13px; min-height: 18px;
}}
QLineEdit:focus, QTextEdit:focus, QComboBox:focus,
QSpinBox:focus, QDoubleSpinBox:focus, QDateEdit:focus, QTimeEdit:focus {{
    border-color: {C_BORDER_FOCUS};
}}
QTableWidget {{
    border: 1px solid {C_BORDER}; border-radius: 16px; background: {C_WHITE};
    gridline-color: #F3F4F6; selection-background-color: {C_PRIMARY_LIGHT};
}}
QTableWidget::item {{ padding: 10px 8px; min-height: 28px; }}
QTableWidget::item:hover {{ background: #F9FAFB; }}
QHeaderView::section {{
    background: {C_PRIMARY}; color: white; padding: 12px 8px;
    border: none; font-weight: 700; font-size: 12px; text-transform: uppercase;
}}
QTabWidget::pane {{ border: 1px solid {C_BORDER}; border-radius: 16px; background: {C_WHITE}; }}
QTabBar::tab {{ padding: 12px 24px; margin-right: 2px; font-size: 13px; font-weight: 500; }}
QTabBar::tab:selected {{ background: {C_PRIMARY}; color: white; border-radius: 6px 6px 0 0; font-weight: 700; }}
QTabBar::tab:hover:!selected {{ background: {C_PRIMARY_LIGHT}; }}
QGroupBox {{ font-weight: 600; border: 1px solid {C_BORDER}; border-radius: 16px; margin-top: 8px; padding-top: 18px; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 14px; padding: 0 8px; }}
QComboBox {{ min-width: 130px; }}
QProgressBar {{ border: none; border-radius: 6px; background: {C_BORDER}; height: 10px; text-align: center; }}
QProgressBar::chunk {{ background: {C_PRIMARY}; border-radius: 6px; }}
QScrollBar:vertical {{ width: 8px; background: transparent; border-radius: 4px; }}
QScrollBar::handle:vertical {{ background: #D1D5DB; border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: {C_TEXT_LIGHT}; }}
QScrollBar:horizontal {{ height: 8px; background: transparent; border-radius: 4px; }}
QScrollBar::handle:horizontal {{ background: #D1D5DB; border-radius: 4px; min-width: 30px; }}
QScrollBar::handle:horizontal:hover {{ background: {C_TEXT_LIGHT}; }}
QDialog {{ background: {C_WHITE}; }}
"""

CARD_STYLE = f"background: {C_WHITE}; border: 1px solid {C_BORDER}; border-radius: 18px; padding: 22px;"
STAT_CARD = f"background: {C_WHITE}; border-radius: 16px; padding: 16px; border-left: 5px solid {C_PRIMARY};"

def add_shadow(widget, blur=20, offset=2, color=QColor(0, 0, 0, 40)):
    shadow = QGraphicsDropShadowEffect()
    shadow.setBlurRadius(blur)
    shadow.setOffset(offset, offset)
    shadow.setColor(color)
    widget.setGraphicsEffect(shadow)

class StatusBadge(QLabel):
    """Pill badge colore pour les statuts (actif, en_attente, etc.)"""
    def __init__(self, text, status_type="info", parent=None):
        super().__init__(text, parent)
        colors = {
            "success": (C_SUCCESS_LIGHT, "#065F46", C_SUCCESS),
            "warning": (C_WARNING_LIGHT, "#92400E", C_WARNING),
            "danger": (C_DANGER_LIGHT, "#991B1B", C_DANGER),
            "info": (C_PRIMARY_LIGHT, C_PRIMARY_DARK, C_PRIMARY),
            "neutral": ("#F3F4F6", "#4B5563", "#9CA3AF"),
        }
        bg, fg, border = colors.get(status_type, colors["neutral"])
        self.setStyleSheet(f"""
            background: {bg}; color: {fg}; border: 1px solid {border};
            border-radius: 12px; padding: 4px 12px; font-size: 11px;
            font-weight: 700;
        """)

# ============================================================
# WIDGETS REUTILISABLES
# ============================================================
class ToastNotification(QFrame):
    """Notification toast moderne avec ombre et animation de fondu"""
    def __init__(self, parent, message, type="success", duration=3500):
        super().__init__(parent)
        self.setFixedHeight(56)
        self.setMinimumWidth(320)
        colors = {
            "success": (C_SUCCESS, C_SUCCESS_LIGHT, "\u2713"),
            "error": (C_DANGER, C_DANGER_LIGHT, "\u2717"),
            "info": (C_PRIMARY, C_PRIMARY_LIGHT, "\u2139"),
            "warning": (C_WARNING, C_WARNING_LIGHT, "\u26A0"),
        }
        border_c, bg_c, icon = colors.get(type, (C_PRIMARY, C_PRIMARY_LIGHT, "\u2139"))
        self.setStyleSheet(f"""
            background: {bg_c}; border-left: 5px solid {border_c};
            border-radius: 16px; padding: 12px 18px;
        """)
        add_shadow(self, blur=24, offset=3, color=QColor(0, 0, 0, 60))
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 0, 16, 0)
        lbl_icon = QLabel(icon)
        lbl_icon.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {border_c};")
        layout.addWidget(lbl_icon)
        lbl_msg = QLabel(message)
        lbl_msg.setStyleSheet(f"font-size: 13px; font-weight: 600; color: {C_TEXT};")
        lbl_msg.setWordWrap(True)
        layout.addWidget(lbl_msg, 1)
        btn_close = QPushButton("\u2716")
        btn_close.setFixedSize(24, 24)
        btn_close.setStyleSheet(f"background: transparent; color: {C_TEXT_SEC}; border: none; font-size: 14px; padding: 0;")
        btn_close.clicked.connect(self.deleteLater)
        layout.addWidget(btn_close)
        # Animation d'entree
        self.anim = QPropertyAnimation(self, b"pos")
        self.anim.setDuration(300)
        self.anim.setEasingCurve(QEasingCurve.OutCubic)
        QTimer.singleShot(duration, self._fade_out)

    def _fade_out(self):
        self.anim = QPropertyAnimation(self, b"pos")
        self.anim.setDuration(250)
        self.anim.setEasingCurve(QEasingCurve.InCubic)
        parent = self.parent()
        if parent:
            start = self.pos()
            end = QPoint(parent.width(), self.pos().y())
            self.anim.setStartValue(start)
            self.anim.setEndValue(end)
            self.anim.finished.connect(self.deleteLater)
            self.anim.start()

class CardWidget(QFrame):
    """Carte medicale avec ombre portee"""
    def __init__(self, title="", parent=None):
        super().__init__(parent)
        self.setStyleSheet(CARD_STYLE)
        add_shadow(self, blur=16, offset=2, color=QColor(0, 0, 0, 25))
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(20, 16, 20, 16)
        if title:
            title_lbl = QLabel(title)
            title_lbl.setStyleSheet(f"font-size: 16px; font-weight: 700; color: {C_TEXT}; padding-bottom: 8px;")
            self.layout.addWidget(title_lbl)

class StatCard(QFrame):
    """Carte statistique avec bordure coloree et ombre"""
    def __init__(self, label, value, color=C_PRIMARY, icon="", parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"{STAT_CARD}; border-left-color: {color};")
        add_shadow(self, blur=12, offset=1, color=QColor(0, 0, 0, 20))
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        if icon:
            hdr = QWidget()
            hl = QHBoxLayout(hdr)
            hl.setContentsMargins(0, 0, 0, 0)
            ic = QLabel(icon)
            ic.setStyleSheet(f"font-size: 22px;")
            hl.addWidget(ic)
            hl.addStretch()
            layout.addWidget(hdr)
        lbl_val = QLabel(str(value))
        lbl_val.setStyleSheet(f"font-size: 32px; font-weight: 800; color: {color}; letter-spacing: -0.5px;")
        lbl_label = QLabel(label)
        lbl_label.setStyleSheet(f"font-size: 13px; color: {C_TEXT_SEC}; font-weight: 500;")
        layout.addWidget(lbl_val)
        layout.addWidget(lbl_label)

EMPTY_MESSAGES = {
    "carnet": ("\U0001F4D6", "Aucune consultation dans votre carnet", "Vos consultations medicales apparaitront ici"),
    "medecins": ("\U0001FA7A", "Aucun medecin lie", "Utilisez le code d'association fourni par votre medecin"),
    "rdv": ("\U0001F4C5", "Aucun rendez-vous", "Prenez rendez-vous avec votre medecin"),
    "prescriptions": ("\U0001F48A", "Aucune prescription", "Vos prescriptions medicales apparaitront ici"),
    "allergies": ("\u26A0\uFE0F", "Aucune allergie enregistree", "Ajoutez vos allergies pour un suivi securise"),
    "examens": ("\U0001F52C", "Aucun examen", "Vos resultats d'examens apparaitront ici"),
    "patients": ("\U0001F465", "Aucun patient lie", "Utilisez l'ID ou le N dossier pour associer un patient"),
    "consultations": ("\U0001F4CB", "Aucune consultation", "Les consultations que vous creez apparaitront ici"),
    "default": ("\U0001F4AD", "Aucune donnee disponible", ""),
}

class TableWithEmpty(QWidget):
    """Tableau avec etat vide stylise et message contextuel"""
    def __init__(self, headers, context="default", parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        self.table = QTableWidget()
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table, 1)
        icon, title, desc = EMPTY_MESSAGES.get(context, EMPTY_MESSAGES["default"])
        empty_w = QWidget()
        empty_w.setStyleSheet(f"background: {C_WHITE}; border: 2px dashed {C_BORDER}; border-radius: 14px;")
        empty_l = QVBoxLayout(empty_w)
        empty_l.setAlignment(Qt.AlignCenter)
        empty_l.setSpacing(8)
        ic = QLabel(icon)
        ic.setStyleSheet(f"font-size: 48px;")
        ic.setAlignment(Qt.AlignCenter)
        empty_l.addWidget(ic)
        self.empty_title = QLabel(title)
        self.empty_title.setStyleSheet(f"font-size: 16px; font-weight: 700; color: {C_TEXT_SEC};")
        self.empty_title.setAlignment(Qt.AlignCenter)
        empty_l.addWidget(self.empty_title)
        self.empty_desc = QLabel(desc)
        self.empty_desc.setStyleSheet(f"font-size: 13px; color: {C_TEXT_LIGHT};")
        self.empty_desc.setAlignment(Qt.AlignCenter)
        empty_l.addWidget(self.empty_desc)
        empty_l.addSpacing(12)
        layout.addWidget(empty_w)
        self.empty_widget = empty_w

    def set_data(self, data):
        self.table.setRowCount(0)
        if not data:
            self.table.hide()
            self.empty_widget.show()
            return
        self.empty_widget.hide()
        self.table.show()
        self.table.setRowCount(len(data))
        for r, row in enumerate(data):
            for c, val in enumerate(row):
                item = QTableWidgetItem(str(val) if val else "")
                item.setFont(QFont("Segoe UI", 12))
                self.table.setItem(r, c, item)

    def update_empty(self, title, desc=""):
        self.empty_title.setText(title)
        self.empty_desc.setText(desc)

def make_btn(text, style="primary", icon=""):
    btn = QPushButton(f"{icon} {text}" if icon else text)
    btn.setCursor(Qt.PointingHandCursor)
    styles = {
        "primary": f"""
            QPushButton {{ background: {C_PRIMARY}; color: white; border: none;
                padding: 10px 24px; border-radius: 12px; font-weight: 600; font-size: 13px; }}
            QPushButton:hover {{ background: {C_PRIMARY_DARK}; }}
            QPushButton:pressed {{ background: #094D8A; }}
        """,
        "danger": f"""
            QPushButton {{ background: {C_DANGER}; color: white; border: none;
                padding: 10px 24px; border-radius: 12px; font-weight: 600; font-size: 13px; }}
            QPushButton:hover {{ background: #DC2626; }}
        """,
        "success": f"""
            QPushButton {{ background: {C_SUCCESS}; color: white; border: none;
                padding: 10px 24px; border-radius: 12px; font-weight: 600; font-size: 13px; }}
            QPushButton:hover {{ background: #059669; }}
        """,
        "outline": f"""
            QPushButton {{ background: {C_WHITE}; color: {C_PRIMARY};
                border: 2px solid {C_BORDER}; padding: 10px 24px;
                border-radius: 12px; font-weight: 600; font-size: 13px; }}
            QPushButton:hover {{ background: {C_PRIMARY_LIGHT}; border-color: {C_PRIMARY}; }}
        """,
    }
    btn.setStyleSheet(styles.get(style, styles["primary"]))
    return btn

class SkeletonLoader(QFrame):
    """Placeholder de chargement avec animation shimmer"""
    def __init__(self, width=400, height=20, parent=None):
        super().__init__(parent)
        self.setFixedSize(width, height)
        self.setStyleSheet(f"""
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 {C_BORDER}, stop:0.4 #F3F4F6, stop:0.6 #F3F4F6, stop:1 {C_BORDER});
            border-radius: 6px;
        """)

def section_title(text):
    lbl = QLabel(text)
    lbl.setStyleSheet(f"font-size: 14px; font-weight: 700; color: {C_TEXT}; padding: 4px 0;")
    return lbl

# ============================================================
# FENETRE DE CONNEXION / INSCRIPTION
# ============================================================
class LoginWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MediCare Santé - Connexion")
        self.setMinimumSize(520, 700)
        self.setStyleSheet(STYLE_BASE)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setAlignment(Qt.AlignCenter)
        layout.setContentsMargins(40, 40, 40, 40)

        # Logo medical premium
        card = QWidget()
        card.setStyleSheet(f"""
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                stop:0 {C_WHITE}, stop:1 #F8FAFC);
            border-radius: 20px; padding: 36px;
            max-width: 460px; margin: 0 auto;
        """)
        cl = QVBoxLayout(card)
        cl.setSpacing(8)
        cl.setAlignment(Qt.AlignCenter)
        add_shadow(card, blur=40, offset=4, color=QColor(15, 108, 189, 50))

        icon_lbl = QLabel("\U0001F3E5")
        icon_lbl.setStyleSheet("font-size: 56px;")
        icon_lbl.setAlignment(Qt.AlignCenter)
        cl.addWidget(icon_lbl)

        titre = QLabel("MediCare Santé")
        titre.setStyleSheet(f"font-size: 26px; font-weight: 700; color: {C_PRIMARY}; text-align: center; letter-spacing: -0.3px;")
        titre.setAlignment(Qt.AlignCenter)
        cl.addWidget(titre)

        sous_titre = QLabel("Plateforme Medicale Professionnelle")
        sous_titre.setStyleSheet(f"font-size: 13px; color: {C_TEXT_SEC}; text-align: center; margin-bottom: 12px;")
        sous_titre.setAlignment(Qt.AlignCenter)
        cl.addWidget(sous_titre)

        deco = QFrame()
        deco.setFixedHeight(3)
        deco.setFixedWidth(60)
        deco.setStyleSheet(f"background: {C_PRIMARY}; border-radius: 2px; margin: 4px 0 12px 0;")
        cl.addWidget(deco)

        layout.addWidget(card)

        # Stack
        self.stack = QStackedWidget()
        layout.addWidget(self.stack)

        self.stack.addWidget(self._build_login_panel())
        self.stack.addWidget(self._build_register_panel())
        self.stack.addWidget(self._build_register_medecin_panel())

    def _card(self, title=""):
        w = QWidget()
        w.setStyleSheet(f"background: {C_WHITE}; border-radius: 12px; max-width: 440px;")
        lo = QVBoxLayout(w)
        lo.setContentsMargins(28, 24, 28, 24)
        lo.setSpacing(14)
        if title:
            t = QLabel(title)
            t.setStyleSheet(f"font-size: 18px; font-weight: 700; color: {C_TEXT}; margin-bottom: 4px;")
            lo.addWidget(t)
        return w, lo

    def _build_login_panel(self):
        panel, lo = self._card("Connexion")

        self.login_email = QLineEdit()
        self.login_email.setPlaceholderText("Entrez votre email")
        lo.addWidget(QLabel("\U0001F4E7  Email"))
        lo.addWidget(self.login_email)

        pwd_row = QWidget()
        prl = QHBoxLayout(pwd_row)
        prl.setContentsMargins(0, 0, 0, 0)
        self.login_password = QLineEdit()
        self.login_password.setPlaceholderText("Mot de passe")
        self.login_password.setEchoMode(QLineEdit.Password)
        prl.addWidget(self.login_password, 1)
        self.toggle_pwd_btn = QPushButton("\U0001F441")
        self.toggle_pwd_btn.setFixedWidth(40)
        self.toggle_pwd_btn.setStyleSheet(f"background: {C_BORDER}; color: {C_TEXT_SEC}; border: none; border-radius: 6px; padding: 8px;")
        self.toggle_pwd_btn.setToolTip("Afficher/Masquer le mot de passe")
        self.toggle_pwd_btn.clicked.connect(self._toggle_password)
        prl.addWidget(self.toggle_pwd_btn)
        lo.addWidget(QLabel("\U0001F512  Mot de passe"))
        lo.addWidget(pwd_row)

        self.login_loading = QProgressBar()
        self.login_loading.setRange(0, 0)
        self.login_loading.hide()
        lo.addWidget(self.login_loading)

        btn_login = make_btn("Se connecter", "primary")
        btn_login.clicked.connect(self._do_login)
        lo.addWidget(btn_login)

        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet(f"color: {C_BORDER}; margin: 4px 0;")
        lo.addWidget(sep)

        btn_create = make_btn("Creer un compte", "success", "\U0001F464")
        btn_create.clicked.connect(self._show_create_account_dialog)
        lo.addWidget(btn_create)

        return panel

    def _toggle_password(self):
        if self.login_password.echoMode() == QLineEdit.Password:
            self.login_password.setEchoMode(QLineEdit.Normal)
            self.toggle_pwd_btn.setText("\U0001F441")
        else:
            self.login_password.setEchoMode(QLineEdit.Password)
            self.toggle_pwd_btn.setText("\U0001F441")

    def _show_create_account_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Creer un compte")
        dialog.setFixedSize(400, 260)
        dialog.setStyleSheet(f"QDialog {{ background: {C_WHITE}; border-radius: 16px; }}")
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)

        title = QLabel("Choisissez le type de compte")
        title.setStyleSheet(f"font-size: 17px; font-weight: 700; color: {C_TEXT};")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        desc = QLabel("Je suis un...")
        desc.setStyleSheet(f"font-size: 13px; color: {C_TEXT_SEC}; text-align: center;")
        desc.setAlignment(Qt.AlignCenter)
        layout.addWidget(desc)

        btn_patient = QPushButton("\U0001F468\u200D\U0001F3EB  Patient - Acceder a mon carnet")
        btn_patient.setStyleSheet(f"background: {C_SUCCESS}; color: white; border: none; padding: 14px; border-radius: 16px; font-weight: 600; font-size: 14px; text-align: left;")
        btn_patient.clicked.connect(lambda: self._choose_register("patient", dialog))
        layout.addWidget(btn_patient)

        btn_medecin = QPushButton("\U0001FA7A  Medecin - Gerer mes patients")
        btn_medecin.setStyleSheet(f"background: {C_PRIMARY}; color: white; border: none; padding: 14px; border-radius: 16px; font-weight: 600; font-size: 14px; text-align: left;")
        btn_medecin.clicked.connect(lambda: self._choose_register("medecin", dialog))
        layout.addWidget(btn_medecin)

        btn_close = QPushButton("Annuler")
        btn_close.setObjectName("btnOutline")
        btn_close.clicked.connect(dialog.reject)
        layout.addWidget(btn_close)

        dialog.exec()

    def _choose_register(self, role, dialog):
        dialog.accept()
        self.stack.setCurrentIndex(1 if role == "patient" else 2)

    def _build_register_panel(self):
        panel, lo = self._card("Inscription Patient")

        self.reg_p_email = QLineEdit(); self.reg_p_email.setPlaceholderText("Email")
        self.reg_p_password = QLineEdit(); self.reg_p_password.setPlaceholderText("Mot de passe (min 8 car.)")
        self.reg_p_password.setEchoMode(QLineEdit.Password)
        self.reg_p_nom = QLineEdit(); self.reg_p_nom.setPlaceholderText("Nom")
        self.reg_p_prenom = QLineEdit(); self.reg_p_prenom.setPlaceholderText("Prenom")
        self.reg_p_date_naiss = QDateEdit(); self.reg_p_date_naiss.setCalendarPopup(True)
        self.reg_p_date_naiss.setDate(QDate(1990, 1, 1))
        self.reg_p_sexe = QComboBox(); self.reg_p_sexe.addItems(["Masculin", "Feminin"])
        self.reg_p_tel = QLineEdit(); self.reg_p_tel.setPlaceholderText("Telephone (optionnel)")
        self.reg_p_adresse = QLineEdit(); self.reg_p_adresse.setPlaceholderText("Adresse (optionnel)")
        self.reg_p_gs = QComboBox(); self.reg_p_gs.addItems(["", "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"])

        for w in [self.reg_p_email, self.reg_p_password, self.reg_p_nom, self.reg_p_prenom]:
            lo.addWidget(section_title(w.placeholderText().split("(")[0].strip()))
            lo.addWidget(w)
        lo.addWidget(section_title("Date naissance"))
        lo.addWidget(self.reg_p_date_naiss)
        lo.addWidget(section_title("Sexe"))
        lo.addWidget(self.reg_p_sexe)
        lo.addWidget(section_title("Telephone"))
        lo.addWidget(self.reg_p_tel)
        lo.addWidget(section_title("Adresse"))
        lo.addWidget(self.reg_p_adresse)
        lo.addWidget(section_title("Groupe sanguin"))
        lo.addWidget(self.reg_p_gs)

        btn = make_btn("Creer mon compte patient", "success", "\U00002714")
        btn.clicked.connect(self._do_register_patient)
        lo.addWidget(btn)

        btn_back = QPushButton("\u2190  Retour")
        btn_back.setObjectName("btnOutline")
        btn_back.clicked.connect(lambda: self.stack.setCurrentIndex(0))
        lo.addWidget(btn_back)

        return panel

    def _build_register_medecin_panel(self):
        panel, lo = self._card("Inscription Medecin")

        self.reg_m_email = QLineEdit(); self.reg_m_email.setPlaceholderText("Email professionnel")
        self.reg_m_password = QLineEdit(); self.reg_m_password.setPlaceholderText("Mot de passe (min 8 car.)")
        self.reg_m_password.setEchoMode(QLineEdit.Password)
        self.reg_m_nom = QLineEdit(); self.reg_m_nom.setPlaceholderText("Nom")
        self.reg_m_prenom = QLineEdit(); self.reg_m_prenom.setPlaceholderText("Prenom")
        self.reg_m_num_ordre = QLineEdit(); self.reg_m_num_ordre.setPlaceholderText("Numero d'ordre")
        self.reg_m_specialite = QLineEdit(); self.reg_m_specialite.setPlaceholderText("Specialite")
        self.reg_m_etablissement = QLineEdit(); self.reg_m_etablissement.setPlaceholderText("Etablissement (optionnel)")
        self.reg_m_tel = QLineEdit(); self.reg_m_tel.setPlaceholderText("Telephone")

        for w in [self.reg_m_email, self.reg_m_password, self.reg_m_nom, self.reg_m_prenom,
                  self.reg_m_num_ordre, self.reg_m_specialite]:
            lo.addWidget(section_title(w.placeholderText()))
            lo.addWidget(w)
        lo.addWidget(section_title("Etablissement"))
        lo.addWidget(self.reg_m_etablissement)
        lo.addWidget(section_title("Telephone"))
        lo.addWidget(self.reg_m_tel)

        note = QLabel("\u2139  Votre compte sera soumis a verification par l'administrateur.")
        note.setStyleSheet(f"font-size: 12px; color: #D97706; background: {C_WARNING_LIGHT}; padding: 10px 14px; border-radius: 12px; font-weight: 500;")
        lo.addWidget(note)

        btn = make_btn("Creer mon compte medecin", "primary", "\U00002714")
        btn.clicked.connect(self._do_register_medecin)
        lo.addWidget(btn)

        btn_back = QPushButton("\u2190  Retour")
        btn_back.setObjectName("btnOutline")
        btn_back.clicked.connect(lambda: self.stack.setCurrentIndex(0))
        lo.addWidget(btn_back)

        return panel

    def _do_login(self):
        email = self.login_email.text().strip()
        password = self.login_password.text()
        if not email or not password:
            QMessageBox.warning(self, "Erreur", "Veuillez remplir tous les champs.")
            return
        self.login_loading.show()
        QApplication.processEvents()
        user = db.authenticate_user(email, password)
        if not user:
            self.login_loading.hide()
            QMessageBox.critical(self, "Erreur", "Email ou mot de passe incorrect.")
            db.log_action(0, "anonymous", "LOGIN_FAILED", "users", details=f"email={email}")
            return
        self.login_loading.hide()
        db.log_action(user['id'], user['role'], "LOGIN", "users", user['id'])

        if user['role'] == 'patient':
            patient = db.get_patient(user_id=user['id'])
            if not patient:
                QMessageBox.critical(self, "Erreur", "Profil patient introuvable.")
                return
            self._open_patient(patient[0], user)
        elif user['role'] == 'medecin':
            medecin = db.get_medecin(user_id=user['id'])
            if not medecin:
                QMessageBox.critical(self, "Erreur", "Profil medecin introuvable.")
                return
            m = medecin[0]
            if m.get('statut') != 'verifie':
                QMessageBox.information(self, "En attente",
                    "Votre compte est en cours de verification par l'administrateur.")
                return
            self._open_medecin(m, user)
        elif user['role'] == 'admin':
            self._open_admin(user)

    def _do_register_patient(self):
        email = self.reg_p_email.text().strip()
        password = self.reg_p_password.text()
        if len(password) < 8:
            QMessageBox.warning(self, "Erreur", "Le mot de passe doit contenir au moins 8 caracteres.")
            return
        nom = self.reg_p_nom.text().strip()
        prenom = self.reg_p_prenom.text().strip()
        if not email or not nom or not prenom:
            QMessageBox.warning(self, "Erreur", "Veuillez remplir tous les champs obligatoires.")
            return
        date_naiss = self.reg_p_date_naiss.date().toString("yyyy-MM-dd")
        sexe = "M" if self.reg_p_sexe.currentText() == "Masculin" else "F"
        tel = self.reg_p_tel.text().strip() or None
        adresse = self.reg_p_adresse.text().strip() or None
        gs = self.reg_p_gs.currentText() or None
        try:
            user_id = db.create_user(email, password, "patient", nom, prenom, tel)
            db.create_patient(user_id, nom, prenom, date_naiss, sexe, adresse=adresse, groupe_sanguin=gs)
            db.log_action(user_id, "patient", "REGISTER", "users", user_id)
            QMessageBox.information(self, "Succes", "Compte cree avec succes! Vous pouvez maintenant vous connecter.")
            for w in [self.reg_p_email, self.reg_p_password, self.reg_p_nom, self.reg_p_prenom, self.reg_p_tel, self.reg_p_adresse]:
                w.clear()
            self.stack.setCurrentIndex(0)
        except Exception as e:
            QMessageBox.critical(self, "Erreur", str(e))

    def _do_register_medecin(self):
        email = self.reg_m_email.text().strip()
        password = self.reg_m_password.text()
        if len(password) < 8:
            QMessageBox.warning(self, "Erreur", "Le mot de passe doit contenir au moins 8 caracteres.")
            return
        nom = self.reg_m_nom.text().strip(); prenom = self.reg_m_prenom.text().strip()
        num_ordre = self.reg_m_num_ordre.text().strip(); specialite = self.reg_m_specialite.text().strip()
        tel = self.reg_m_tel.text().strip()
        if not email or not nom or not prenom or not num_ordre or not specialite or not tel:
            QMessageBox.warning(self, "Erreur", "Veuillez remplir tous les champs obligatoires.")
            return
        try:
            user_id = db.create_user(email, password, "medecin", nom, prenom, tel)
            db.create_medecin(user_id, num_ordre, nom, prenom, specialite,
                             self.reg_m_etablissement.text().strip() or None, tel, email)
            db.log_action(user_id, "medecin", "REGISTER", "medecins", user_id)
            QMessageBox.information(self, "Succes", "Compte cree! En attente de verification par l'administrateur.")
            for w in [self.reg_m_email, self.reg_m_password, self.reg_m_nom, self.reg_m_prenom,
                      self.reg_m_num_ordre, self.reg_m_specialite, self.reg_m_etablissement, self.reg_m_tel]:
                w.clear()
            self.stack.setCurrentIndex(0)
        except Exception as e:
            QMessageBox.critical(self, "Erreur", str(e))

    def _open_patient(self, patient, user):
        self.patient_window = PatientWindow(patient, user)
        self.patient_window.show()
        self.hide()

    def _open_medecin(self, medecin, user):
        self.medecin_window = MedecinWindow(medecin, user)
        self.medecin_window.show()
        self.hide()

    def _open_admin(self, user):
        self.admin_window = AdminWindow(user)
        self.admin_window.show()
        self.hide()

# ============================================================
# FENETRE PATIENT
# ============================================================
class PatientWindow(QMainWindow):
    def __init__(self, patient, user):
        super().__init__()
        self.patient = patient
        self.user = user
        self.setWindowTitle(f"Carnet Medical - {patient['prenom']} {patient['nom']}")
        self.setMinimumSize(1200, 750)
        self.setStyleSheet(STYLE_BASE)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Sidebar
        sidebar = QFrame()
        sidebar.setFixedWidth(240)
        sidebar.setStyleSheet(f"background: {C_PRIMARY};")
        sb_layout = QVBoxLayout(sidebar)
        sb_layout.setContentsMargins(0, 0, 0, 0)
        sb_layout.setSpacing(0)

        # Profil sidebar
        profile = QFrame()
        profile.setStyleSheet(f"background: {C_PRIMARY_DARK}; padding: 20px;")
        pl = QVBoxLayout(profile)
        pl.setContentsMargins(16, 20, 16, 20)
        pl.setSpacing(4)
        avatar = QLabel("\U0001F468\u200D\U0001F393")
        avatar.setStyleSheet("font-size: 40px;")
        pl.addWidget(avatar)
        sb_name = QLabel(f"{patient['prenom']} {patient['nom']}")
        sb_name.setStyleSheet("font-size: 16px; font-weight: 700; color: white;")
        pl.addWidget(sb_name)
        sb_dos = QLabel(f"Dossier: {patient.get('numero_dossier','')}")
        sb_dos.setStyleSheet(f"font-size: 11px; color: #93C5FD;")
        pl.addWidget(sb_dos)
        sb_layout.addWidget(profile)

        self.nav_buttons = []
        nav_items = [
            ("tableau_bord", "\U0001F4CA  Tableau de bord"),
            ("carnet", "\U0001F4D6  Mon Carnet"),
            ("medecins", "\U0001FA7A  Mes Medecins"),
            ("rendezvous", "\U0001F4C5  Rendez-vous"),
            ("prescriptions", "\U0001F48A  Prescriptions"),
            ("allergies", "\u26A0\uFE0F  Allergies"),
            ("examens", "\U0001F52C  Examens"),
        ]
        for key, label in nav_items:
            btn = QPushButton(label)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setMinimumHeight(46)
            btn.setStyleSheet("""
                QPushButton { background: transparent; color: #DBEAFE; border: none; border-radius: 12px;
                    padding: 12px 18px; text-align: left; font-size: 14px; font-weight: 500; margin: 4px 8px; }
                QPushButton:hover { background: rgba(255,255,255,0.14); color: white; }
                QPushButton:checked { background: rgba(255,255,255,0.22); color: white;
                    font-weight: 700; border-left: 4px solid white; }
            """)
            btn.setCheckable(True)
            btn.clicked.connect(lambda checked, k=key: self._show_page(k))
            sb_layout.addWidget(btn)
            self.nav_buttons.append((key, btn))

        sb_layout.addStretch()

        btn_logout = QPushButton("  Deconnexion")
        btn_logout.setCursor(Qt.PointingHandCursor)
        btn_logout.setStyleSheet(f"""
            QPushButton {{ background: transparent; color: #FECACA; border: none;
                border-top: 1px solid rgba(255,255,255,0.15);
                padding: 16px 20px; text-align: left; font-size: 13px; font-weight: 500; }}
            QPushButton:hover {{ background: {C_DANGER}; color: white; }}
        """)
        btn_logout.clicked.connect(self._logout)
        sb_layout.addWidget(btn_logout)

        layout.addWidget(sidebar)

        # Main
        self.content_stack = QStackedWidget()
        self.content_pages = {}
        pages = [
            ("tableau_bord", self._build_dashboard()),
            ("carnet", self._build_carnet()),
            ("medecins", self._build_medecins()),
            ("rendezvous", self._build_rendezvous()),
            ("prescriptions", self._build_prescriptions()),
            ("allergies", self._build_allergies()),
            ("examens", self._build_examens()),
        ]
        for key, page in pages:
            self.content_pages[key] = page
            self.content_stack.addWidget(page)

        layout.addWidget(self.content_stack, 1)
        self._show_page("tableau_bord")

    def _show_page(self, key):
        for k, btn in self.nav_buttons:
            btn.setChecked(k == key)
        if key in self.content_pages:
            self.content_stack.setCurrentWidget(self.content_pages[key])
            if key == "carnet": self._refresh_carnet()
            elif key == "medecins": self._refresh_medecins()
            elif key == "rendezvous": self._refresh_rdv()
            elif key == "prescriptions": self._refresh_prescriptions()
            elif key == "allergies": self._refresh_allergies()
            elif key == "examens": self._refresh_examens()
            elif key == "tableau_bord": self._refresh_dashboard()

    def _logout(self):
        db.log_action(self.user['id'], "patient", "LOGOUT", "users", self.user['id'])
        self.login = LoginWindow()
        self.login.show()
        self.close()

    def _build_dashboard(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)

        header = QWidget()
        hl = QHBoxLayout(header)
        hl.setContentsMargins(0, 0, 0, 0)
        self.dash_welcome = QLabel()
        self.dash_welcome.setStyleSheet(f"font-size: 22px; font-weight: 700; color: {C_TEXT};")
        hl.addWidget(self.dash_welcome)
        self.dash_badge = QLabel()
        self.dash_badge.setStyleSheet(f"background: {C_SUCCESS_LIGHT}; color: #065F46; padding: 6px 16px; border-radius: 20px; font-size: 13px; font-weight: 600;")
        hl.addWidget(self.dash_badge)
        hl.addStretch()
        layout.addWidget(header)

        self.dash_stats = QWidget()
        self.dash_stats.setLayout(QHBoxLayout())
        layout.addWidget(self.dash_stats)

        row2 = QSplitter(Qt.Horizontal)
        info_card = CardWidget(" Informations personnelles")
        self.dash_info = QWidget()
        self.dash_info.setLayout(QFormLayout())
        info_card.layout.addWidget(self.dash_info)
        row2.addWidget(info_card)

        quick_card = CardWidget(" Actions rapides")
        self.dash_quick_layout = QVBoxLayout()
        quick_card.layout.addLayout(self.dash_quick_layout)
        row2.addWidget(quick_card)
        row2.setSizes([400, 400])
        layout.addWidget(row2, 1)
        return page

    def _refresh_dashboard(self):
        p = self.patient
        self.dash_welcome.setText(f"Bonjour, {p['prenom']} {p['nom']}")

        patient_id = p['id']
        consults = db.get_consultations_by_patient(patient_id) or []
        prescs = db.get_prescriptions_by_patient(patient_id) or []
        rdvs = db.get_rendezvous_by_patient(patient_id) or []
        allergies = db.get_allergies_by_patient(patient_id) or []
        links = db._execute("SELECT * FROM patient_medecin_links WHERE patient_id=? AND statut='actif'",
                           (patient_id,), fetchall=True) or []
        today_rdvs = [r for r in rdvs if r.get('date_rdv') == date.today().isoformat()]

        badge = ""
        if today_rdvs:
            badge = f"\U0001F514 {len(today_rdvs)} RDV aujourd'hui"
        elif rdvs:
            next_rdv = rdvs[0]
            badge = f"\U0001F4C5 Prochain: {next_rdv.get('date_rdv','')}"
        self.dash_badge.setText(badge)
        self.dash_badge.setVisible(bool(badge))

        old = self.dash_stats.layout()
        while old.count():
            w = old.takeAt(0).widget()
            if w: w.deleteLater()

        stats_w = QWidget()
        sl = QHBoxLayout(stats_w)
        sl.setSpacing(16)
        for lbl, val, col, ic in [
            ("Consultations", len(consults), C_PRIMARY, "\U0001F4CB"),
            ("Prescriptions", len(prescs), C_SUCCESS, "\U0001F48A"),
            ("Rendez-vous", len(rdvs), C_WARNING, "\U0001F4C5"),
            ("Allergies", len(allergies), C_DANGER, "\u26A0\uFE0F"),
            ("Medecins", len(links), "#8B5CF6", "\U0001FA7A"),
        ]:
            sl.addWidget(StatCard(lbl, val, col, ic))
        old.addWidget(stats_w)

        info_layout = self.dash_info.layout()
        while info_layout.count(): info_layout.removeRow(info_layout.rowCount()-1)
        for label, val in [
            ("Dossier", p.get("numero_dossier","")),
            ("Date naissance", p.get("date_naissance","")),
            ("Sexe", "Masculin" if p.get("sexe")=="M" else "Feminin"),
            ("Groupe", p.get("groupe_sanguin","N/A")),
            ("Taille", f'{p.get("taille_cm","")} cm' if p.get("taille_cm") else "N/A"),
            ("Poids", f'{p.get("poids_kg","")} kg' if p.get("poids_kg") else "N/A"),
            ("Telephone", p.get("telephone","N/A")),
        ]:
            l = QLabel(f"<b>{label}:</b>")
            l.setStyleSheet(f"color: {C_TEXT_SEC};")
            v = QLabel(str(val))
            v.setStyleSheet(f"color: {C_TEXT}; font-weight: 500;")
            info_layout.addRow(l, v)

        while self.dash_quick_layout.count():
            w = self.dash_quick_layout.takeAt(0).widget()
            if w: w.deleteLater()
        for txt, cb in [
            ("\U0001F4D6  Consulter mon carnet", lambda: self._show_page("carnet")),
            ("\U0001F4C5  Mes rendez-vous", lambda: self._show_page("rendezvous")),
            ("\U0001FA7A  Gerer mes medecins", lambda: self._show_page("medecins")),
        ]:
            btn = QPushButton(txt)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setStyleSheet(f"""
                QPushButton {{ text-align: left; padding: 14px 18px; font-size: 14px;
                    background: {C_WHITE}; border: 2px solid {C_BORDER}; border-radius: 16px;
                    color: {C_TEXT}; font-weight: 500; }}
                QPushButton:hover {{ background: {C_PRIMARY_LIGHT}; color: {C_PRIMARY}; border-color: {C_PRIMARY}; }}
            """)
            btn.clicked.connect(cb)
            self.dash_quick_layout.addWidget(btn)

    def _build_carnet(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)

        title = QLabel("\U0001F4D6  Mon Carnet Medical")
        title.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {C_TEXT}; margin-bottom: 8px;")
        layout.addWidget(title)

        search_bar = QWidget()
        search_layout = QHBoxLayout(search_bar)
        search_layout.setContentsMargins(0, 0, 0, 12)
        self.kmp_input = QLineEdit()
        self.kmp_input.setPlaceholderText("Rechercher dans l'historique médical...")
        self.kmp_input.returnPressed.connect(self._kmp_search)
        btn_search = make_btn("Rechercher", "primary", "\U0001F50D")
        btn_search.clicked.connect(self._kmp_search)
        search_layout.addWidget(self.kmp_input, 1)
        search_layout.addWidget(btn_search)
        layout.addWidget(search_bar)

        self.carnet_status_label = QLabel("Entrez un mot-clé pour trouver rapidement une consultation.")
        self.carnet_status_label.setStyleSheet(f"color: {C_TEXT_SEC}; font-size: 13px; margin-bottom: 10px;")
        layout.addWidget(self.carnet_status_label)

        self.carnet_table = TableWithEmpty(["Date", "Heure", "Médecin", "Motif", "Diagnostic", "Observations", "Traitement"], "carnet")
        layout.addWidget(self.carnet_table, 1)
        return page

    def _refresh_carnet(self):
        self._load_consultations()

    def _load_consultations(self, search_query=""):
        consults = db.get_consultations_by_patient(self.patient['id']) or []
        if search_query:
            consults = search_medical_history(consults, search_query)
        data = []
        qty_hash = PatientHashTable()
        avl = AVLTree()
        for c in consults:
            data.append([
                c.get('date_consultation',''), c.get('heure_consultation',''),
                f"{c.get('medecin_prenom','')} {c.get('medecin_nom','')}",
                c.get('motif',''), c.get('diagnostic',''),
                c.get('observations',''), c.get('traitement','')
            ])
            key = f"CONS-{c['id']}"
            qty_hash.insert(key, c)
            try:
                d = datetime.strptime(c['date_consultation'], '%Y-%m-%d')
                avl.insert(d, c)
            except: pass
        self.carnet_table.set_data(data)

    def _kmp_search(self):
        query = self.kmp_input.text().strip()
        self._load_consultations(query)

    def _build_medecins(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)

        title = QLabel("\U0001FA7A  Mes Medecins")
        title.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {C_TEXT}; margin-bottom: 8px;")
        layout.addWidget(title)

        assoc = QWidget()
        assoc_layout = QHBoxLayout(assoc)
        assoc_layout.setContentsMargins(0, 0, 0, 12)
        self.assoc_code = QLineEdit()
        self.assoc_code.setPlaceholderText("Entrez le code d'association fourni par votre medecin")
        btn_assoc = make_btn("Valider l'association", "success", "\U00002714")
        btn_assoc.clicked.connect(self._validate_association)
        assoc_layout.addWidget(self.assoc_code, 1)
        assoc_layout.addWidget(btn_assoc)
        layout.addWidget(assoc)

        self.medecins_table = TableWithEmpty(["Medecin", "Specialite", "Etablissement", "Statut", "Telephone", "Action"], "medecins")
        layout.addWidget(self.medecins_table, 1)
        return page

    def _refresh_medecins(self):
        links = db._execute(
            """SELECT l.*, m.specialite, m.etablissement, u.nom, u.prenom, u.telephone
               FROM patient_medecin_links l
               JOIN medecins m ON l.medecin_id = m.id
               JOIN users u ON m.user_id = u.id
               WHERE l.patient_id = ?""",
            (self.patient['id'],), fetchall=True) or []
        data = []
        for l in links:
            data.append([f"Dr. {l.get('prenom','')} {l.get('nom','')}", l.get('specialite',''),
                         l.get('etablissement',''), l.get('statut',''), l.get('telephone',''), ""])
        self.medecins_table.set_data(data)
        for r, l in enumerate(links):
            if l.get('statut') == 'actif':
                btn = make_btn("Revoguer", "danger", "\u274C")
                btn.clicked.connect(lambda checked, lid=l['id']: self._revoke_medecin(lid))
                self.medecins_table.table.setCellWidget(r, 5, btn)
            elif l.get('statut') == 'en_attente':
                lbl = QLabel("  \u23F3 En attente de validation")
                lbl.setStyleSheet(f"color: {C_WARNING}; font-weight: 600; padding: 4px;")
                self.medecins_table.table.setCellWidget(r, 5, lbl)

    def _validate_association(self):
        code = self.assoc_code.text().strip()
        if not code:
            QMessageBox.warning(self, "Erreur", "Entrez un code d'association.")
            return
        if db.validate_link(code, self.patient['id']):
            db.log_action(self.user['id'], "patient", "VALIDATE_ASSOCIATION", "patient_medecin_links", details=f"code={code}")
            QMessageBox.information(self, "Succes", "Association validee avec succes!")
            self.assoc_code.clear()
            self._refresh_medecins()
        else:
            QMessageBox.critical(self, "Erreur", "Code invalide ou deja utilise.")

    def _revoke_medecin(self, link_id):
        if QMessageBox.question(self, "Confirmation", "Revoguer l'acces de ce medecin a votre dossier?",
                                QMessageBox.Yes|QMessageBox.No) == QMessageBox.Yes:
            db.revoke_link(link_id, "patient")
            db.log_action(self.user['id'], "patient", "REVOKE_MEDECIN", "patient_medecin_links", link_id)
            self._refresh_medecins()

    def _build_rendezvous(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)
        title = QLabel("\U0001F4C5  Mes Rendez-vous")
        title.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {C_TEXT}; margin-bottom: 8px;")
        layout.addWidget(title)
        self.rdv_table = TableWithEmpty(["Date", "Heure", "Motif", "Type", "Statut"], "rdv")
        layout.addWidget(self.rdv_table, 1)
        return page

    def _refresh_rdv(self):
        rdvs = db.get_rendezvous_by_patient(self.patient['id']) or []
        heap = AppointmentHeap()
        data = []
        for rdv in rdvs:
            data.append([rdv.get('date_rdv',''), f"{rdv.get('heure_debut','')} - {rdv.get('heure_fin','')}",
                         rdv.get('motif',''), rdv.get('type',''), rdv.get('statut','')])
            heap.push(rdv.get('priorite', 1), rdv)
        self.rdv_table.set_data(data)

    def _build_prescriptions(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)
        title = QLabel("\U0001F48A  Mes Prescriptions")
        title.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {C_TEXT}; margin-bottom: 8px;")
        layout.addWidget(title)
        self.presc_table = TableWithEmpty(["Titre", "Contenu", "Medecin", "Date debut", "Date fin", "Statut"], "prescriptions")
        layout.addWidget(self.presc_table, 1)
        return page

    def _refresh_prescriptions(self):
        prescs = db.get_prescriptions_by_patient(self.patient['id']) or []
        data = []
        for p in prescs:
            data.append([p.get('titre',''), p.get('contenu',''),
                         f"Dr. {p.get('medecin_prenom','')} {p.get('medecin_nom','')}",
                         p.get('date_debut',''), p.get('date_fin',''), p.get('statut','')])
        self.presc_table.set_data(data)

    def _build_allergies(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)

        title_row = QWidget()
        trl = QHBoxLayout(title_row)
        trl.setContentsMargins(0, 0, 0, 8)
        t = QLabel("\u26A0\uFE0F  Allergies")
        t.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {C_TEXT};")
        trl.addWidget(t)
        trl.addStretch()
        btn_add = make_btn("Ajouter une allergie", "warning", "\u2795")
        btn_add.clicked.connect(self._add_allergie)
        trl.addWidget(btn_add)
        layout.addWidget(title_row)

        self.allergies_table = TableWithEmpty(["Allergene", "Reaction", "Description", "Date", "Action"], "allergies")
        layout.addWidget(self.allergies_table, 1)
        return page

    def _refresh_allergies(self):
        allergies = db.get_allergies_by_patient(self.patient['id']) or []
        data = []
        for a in allergies:
            data.append([a.get('allergene',''), a.get('type_reaction',''), a.get('description',''),
                         a.get('date_diagnostic','') or a.get('created_at',''), ""])
        self.allergies_table.set_data(data)
        for r, a in enumerate(allergies):
            btn = make_btn("Supprimer", "danger", "\u274C")
            btn.clicked.connect(lambda checked, aid=a['id']: self._delete_allergie(aid))
            self.allergies_table.table.setCellWidget(r, 4, btn)

    def _add_allergie(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Ajouter une allergie")
        dialog.setMinimumWidth(450)
        dialog.setStyleSheet(f"QDialog {{ background: {C_WHITE}; }}")
        layout = QFormLayout(dialog)
        layout.setSpacing(12)
        layout.setContentsMargins(24, 20, 24, 20)
        allergene = QLineEdit(); allergene.setPlaceholderText("Ex: Penicilline")
        reaction = QComboBox(); reaction.addItems(["legere", "moderee", "severe", "anaphylaxie"])
        description = QTextEdit(); description.setPlaceholderText("Description des symptomes...")
        description.setMaximumHeight(80)
        date_diag = QDateEdit(); date_diag.setCalendarPopup(True); date_diag.setDate(QDate.currentDate())
        layout.addRow("Allergene:", allergene)
        layout.addRow("Reaction:", reaction)
        layout.addRow("Description:", description)
        layout.addRow("Date diagnostic:", date_diag)
        btn_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btn_box.accepted.connect(dialog.accept)
        btn_box.rejected.connect(dialog.reject)
        layout.addRow(btn_box)
        if dialog.exec() == QDialog.Accepted and allergene.text().strip():
            db.create_allergie(self.patient['id'], allergene.text().strip(),
                              reaction.currentText(), description.toPlainText().strip() or None,
                              date_diag.date().toString("yyyy-MM-dd"))
            db.log_action(self.user['id'], "patient", "ADD_ALLERGIE", "allergies", details=f"allergene={allergene.text()}")
            self._refresh_allergies()
            self._show_toast("Allergie ajoutee avec succes", "success")

    def _delete_allergie(self, allergy_id):
        if QMessageBox.question(self, "Confirmation", "Supprimer cette allergie?",
                                QMessageBox.Yes|QMessageBox.No) == QMessageBox.Yes:
            db.delete_allergie(allergy_id)
            db.log_action(self.user['id'], "patient", "DELETE_ALLERGIE", "allergies", allergy_id)
            self._refresh_allergies()
            self._show_toast("Allergie supprimee", "success")

    def _build_examens(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)

        title_row = QWidget()
        trl = QHBoxLayout(title_row)
        trl.setContentsMargins(0, 0, 0, 8)
        t = QLabel("\U0001F52C  Examens")
        t.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {C_TEXT};")
        trl.addWidget(t)
        trl.addStretch()
        btn_add = make_btn("Ajouter un examen", "primary", "\u2795")
        btn_add.clicked.connect(self._add_examen)
        trl.addWidget(btn_add)
        layout.addWidget(title_row)

        self.examens_table = TableWithEmpty(["Type", "Date", "Resultats", "Valeurs"], "examens")
        layout.addWidget(self.examens_table, 1)
        return page

    def _refresh_examens(self):
        examens = db.get_examens_by_patient(self.patient['id']) or []
        data = []
        for e in examens:
            data.append([e.get('type_examen',''), e.get('date_examen',''),
                         e.get('resultats',''), e.get('valeurs','')])
        self.examens_table.set_data(data)

    def _add_examen(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Ajouter un examen")
        dialog.setMinimumWidth(450)
        dialog.setStyleSheet(f"QDialog {{ background: {C_WHITE}; }}")
        layout = QFormLayout(dialog)
        layout.setSpacing(12)
        layout.setContentsMargins(24, 20, 24, 20)
        type_exam = QLineEdit(); type_exam.setPlaceholderText("IRM, prise de sang, radio...")
        date_exam = QDateEdit(); date_exam.setCalendarPopup(True); date_exam.setDate(QDate.currentDate())
        resultats = QTextEdit(); resultats.setPlaceholderText("Resultats de l'examen..."); resultats.setMaximumHeight(100)
        layout.addRow("Type:", type_exam)
        layout.addRow("Date:", date_exam)
        layout.addRow("Resultats:", resultats)
        btn_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btn_box.accepted.connect(dialog.accept)
        btn_box.rejected.connect(dialog.reject)
        layout.addRow(btn_box)
        if dialog.exec() == QDialog.Accepted and type_exam.text().strip():
            db.create_examen(self.patient['id'], 0, 0, type_exam.text().strip(),
                           resultats.toPlainText().strip() or None,
                           date_examen=date_exam.date().toString("yyyy-MM-dd"))
            db.log_action(self.user['id'], "patient", "ADD_EXAMEN", "examens", details=f"type={type_exam.text()}")
            self._refresh_examens()
            self._show_toast("Examen ajoute avec succes", "success")

    def _show_toast(self, message, type="success"):
        toast = ToastNotification(self.content_stack, message, type)
        toast.show()
        # Positionner en haut a droite
        pw = self.content_stack.width()
        tw = 350
        toast.setGeometry(pw - tw - 20, 16, tw, 52)

# ============================================================
# FENETRE MEDECIN
# ============================================================
class MedecinWindow(QMainWindow):
    def __init__(self, medecin, user):
        super().__init__()
        self.medecin = medecin
        self.user = user
        self.setWindowTitle(f"Carnet Medical - Dr. {medecin['prenom']} {medecin['nom']}")
        self.setMinimumSize(1200, 750)
        self.setStyleSheet(STYLE_BASE)

        self.patient_cache = PatientHashTable()
        self._init_patient_cache()

        central = QWidget()
        self.setCentralWidget(central)
        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        sidebar = QFrame()
        sidebar.setFixedWidth(240)
        sidebar.setStyleSheet(f"background: {C_PRIMARY};")
        sb_layout = QVBoxLayout(sidebar)
        sb_layout.setContentsMargins(0, 0, 0, 0)
        sb_layout.setSpacing(0)

        profile = QFrame()
        profile.setStyleSheet(f"background: {C_PRIMARY_DARK}; padding: 20px;")
        pl = QVBoxLayout(profile)
        pl.setContentsMargins(16, 20, 16, 20)
        pl.setSpacing(4)
        avatar = QLabel("\U0001FA7A")
        avatar.setStyleSheet("font-size: 40px;")
        pl.addWidget(avatar)
        sb_name = QLabel(f"Dr. {medecin['prenom']} {medecin['nom']}")
        sb_name.setStyleSheet("font-size: 16px; font-weight: 700; color: white;")
        pl.addWidget(sb_name)
        sb_spc = QLabel(f"{medecin.get('specialite','')}")
        sb_spc.setStyleSheet(f"font-size: 12px; color: #93C5FD;")
        pl.addWidget(sb_spc)
        sb_layout.addWidget(profile)

        self.nav_buttons = []
        nav_items = [
            ("tableau_bord", "\U0001F4CA  Tableau de bord"),
            ("patients", "\U0001F465  Mes Patients"),
            ("consultations", "\U0001F4CB  Consultations"),
            ("rendezvous", "\U0001F4C5  Rendez-vous"),
            ("prescriptions", "\U0001F48A  Prescriptions"),
            ("recherche", "\U0001F50D  Recherche"),
        ]
        for key, label in nav_items:
            btn = QPushButton(label)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setMinimumHeight(46)
            btn.setStyleSheet("""
                QPushButton { background: transparent; color: #DBEAFE; border: none; border-radius: 12px;
                    padding: 12px 18px; text-align: left; font-size: 14px; font-weight: 500; margin: 4px 8px; }
                QPushButton:hover { background: rgba(255,255,255,0.14); color: white; }
                QPushButton:checked { background: rgba(255,255,255,0.22); color: white;
                    font-weight: 700; border-left: 4px solid white; }
            """)
            btn.setCheckable(True)
            btn.clicked.connect(lambda checked, k=key: self._show_page(k))
            sb_layout.addWidget(btn)
            self.nav_buttons.append((key, btn))

        sb_layout.addStretch()
        btn_logout = QPushButton("  Deconnexion")
        btn_logout.setCursor(Qt.PointingHandCursor)
        btn_logout.setStyleSheet(f"""
            QPushButton {{ background: transparent; color: #FECACA; border: none;
                border-top: 1px solid rgba(255,255,255,0.15);
                padding: 16px 20px; text-align: left; font-size: 13px; font-weight: 500; }}
            QPushButton:hover {{ background: {C_DANGER}; color: white; }}
        """)
        btn_logout.clicked.connect(self._logout)
        sb_layout.addWidget(btn_logout)

        layout.addWidget(sidebar)

        self.content_stack = QStackedWidget()
        self.content_pages = {}
        pages = [
            ("tableau_bord", self._build_dashboard()),
            ("patients", self._build_patients()),
            ("consultations", self._build_consultations()),
            ("rendezvous", self._build_rendezvous()),
            ("prescriptions", self._build_prescriptions()),
            ("recherche", self._build_recherche()),
        ]
        for key, page in pages:
            self.content_pages[key] = page
            self.content_stack.addWidget(page)

        layout.addWidget(self.content_stack, 1)
        self._show_page("tableau_bord")

    def _init_patient_cache(self):
        patients = db._execute(
            """SELECT p.*, u.nom, u.prenom, u.telephone
               FROM patients p JOIN users u ON p.user_id = u.id""",
            (), fetchall=True) or []
        for p in patients:
            self.patient_cache.insert(p.get('numero_dossier',''), p)
            self.patient_cache.insert(str(p['id']), p)

    def _show_page(self, key):
        for k, btn in self.nav_buttons:
            btn.setChecked(k == key)
        if key in self.content_pages:
            self.content_stack.setCurrentWidget(self.content_pages[key])
            if key == "patients": self._refresh_patients()
            elif key == "consultations": self._refresh_consultations()
            elif key == "rendezvous": self._refresh_rdv()
            elif key == "prescriptions": self._refresh_prescriptions()
            elif key == "tableau_bord": self._refresh_dashboard()

    def _logout(self):
        db.log_action(self.user['id'], "medecin", "LOGOUT", "users", self.user['id'])
        self.login = LoginWindow()
        self.login.show()
        self.close()

    def _build_dashboard(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)

        header = QWidget()
        hl = QHBoxLayout(header)
        hl.setContentsMargins(0, 0, 0, 0)
        self.dash_welcome = QLabel()
        self.dash_welcome.setStyleSheet(f"font-size: 22px; font-weight: 700; color: {C_TEXT};")
        hl.addWidget(self.dash_welcome)
        self.dash_badge = QLabel()
        self.dash_badge.setStyleSheet(f"background: {C_PRIMARY_LIGHT}; color: {C_PRIMARY_DARK}; padding: 6px 16px; border-radius: 20px; font-size: 13px; font-weight: 600;")
        hl.addWidget(self.dash_badge)
        hl.addStretch()
        layout.addWidget(header)

        self.dash_stats = QWidget()
        self.dash_stats.setLayout(QHBoxLayout())
        layout.addWidget(self.dash_stats)

        row2 = QSplitter(Qt.Horizontal)
        quick_card = CardWidget(" Actions rapides")
        self.dash_quick_layout = QVBoxLayout()
        quick_card.layout.addLayout(self.dash_quick_layout)
        row2.addWidget(quick_card)

        info_card = CardWidget(" Informations")
        self.dash_info_layout = QFormLayout()
        info_card.layout.addLayout(self.dash_info_layout)
        row2.addWidget(info_card)
        row2.setSizes([400, 400])
        layout.addWidget(row2, 1)
        return page

    def _refresh_dashboard(self):
        m = self.medecin
        self.dash_welcome.setText(f"Dr. {m['prenom']} {m['nom']} - {m.get('specialite','')}")

        patients = db.get_patient_medecins(m['id']) or []
        consults = db.get_consultations_by_medecin(m['id']) or []
        rdvs = db.get_rendezvous_by_medecin(m['id']) or []
        prescs = db.get_prescriptions_by_medecin(m['id']) or []
        today_rdvs = [r for r in rdvs if r.get('date_rdv') == date.today().isoformat()]

        badge = ""
        if today_rdvs:
            badge = f"\U0001F514 {len(today_rdvs)} RDV aujourd'hui"
        self.dash_badge.setText(badge)
        self.dash_badge.setVisible(bool(badge))

        old = self.dash_stats.layout()
        while old.count():
            w = old.takeAt(0).widget()
            if w: w.deleteLater()

        stats_w = QWidget()
        sl = QHBoxLayout(stats_w)
        sl.setSpacing(16)
        for lbl, val, col, ic in [
            ("Patients", len(patients), C_PRIMARY, "\U0001F465"),
            ("Consultations", len(consults), C_SUCCESS, "\U0001F4CB"),
            ("Rendez-vous", len(rdvs), C_WARNING, "\U0001F4C5"),
            ("Prescriptions", len(prescs), "#8B5CF6", "\U0001F48A"),
        ]:
            sl.addWidget(StatCard(lbl, val, col, ic))
        old.addWidget(stats_w)

        while self.dash_quick_layout.count():
            w = self.dash_quick_layout.takeAt(0).widget()
            if w: w.deleteLater()
        for txt, cb in [
            ("\U0001F465  Voir mes patients", lambda: self._show_page("patients")),
            ("\U0001F4CB  Nouvelle consultation", lambda: self._show_page("consultations")),
            ("\U0001F4C5  Gerer rendez-vous", lambda: self._show_page("rendezvous")),
        ]:
            btn = QPushButton(txt)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setStyleSheet(f"""
                QPushButton {{ text-align: left; padding: 14px 18px; font-size: 14px;
                    background: {C_WHITE}; border: 2px solid {C_BORDER}; border-radius: 16px;
                    color: {C_TEXT}; font-weight: 500; }}
                QPushButton:hover {{ background: {C_PRIMARY_LIGHT}; color: {C_PRIMARY}; border-color: {C_PRIMARY}; }}
            """)
            btn.clicked.connect(cb)
            self.dash_quick_layout.addWidget(btn)

        info_layout = self.dash_info_layout
        while info_layout.count(): info_layout.removeRow(info_layout.rowCount()-1)
        for l, v in [
            ("Specialite", m.get("specialite","")),
            ("Etablissement", m.get("etablissement","N/A")),
            ("N Ordre", m.get("numero_ordre","")),
            ("Statut", m.get("statut","")),
            ("Patients actifs", str(len(patients))),
            ("Consultations", str(len(consults))),
        ]:
            lbl = QLabel(f"<b>{l}:</b>")
            lbl.setStyleSheet(f"color: {C_TEXT_SEC};")
            val = QLabel(str(v))
            val.setStyleSheet(f"color: {C_TEXT}; font-weight: 500;")
            info_layout.addRow(lbl, val)

    def _build_patients(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)

        title_row = QWidget()
        trl = QHBoxLayout(title_row)
        trl.setContentsMargins(0, 0, 0, 8)
        t = QLabel("\U0001F465  Mes Patients")
        t.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {C_TEXT};")
        trl.addWidget(t)
        trl.addStretch()
        layout.addWidget(title_row)

        assoc = QWidget()
        al = QHBoxLayout(assoc)
        al.setContentsMargins(0, 0, 0, 12)
        self.assoc_patient_input = QLineEdit()
        self.assoc_patient_input.setPlaceholderText("ID ou N dossier du patient")
        btn_assoc = make_btn("Demander association", "primary", "\U0001F517")
        btn_assoc.clicked.connect(self._request_association)
        al.addWidget(self.assoc_patient_input, 1)
        al.addWidget(btn_assoc)
        self.assoc_code_label = QLabel("")
        self.assoc_code_label.setStyleSheet(f"color: {C_SUCCESS}; font-weight: 600; padding: 0 8px;")
        al.addWidget(self.assoc_code_label)
        layout.addWidget(assoc)

        self.patients_table = TableWithEmpty(["Patient", "Dossier", "Naissance", "Telephone", "Statut"], "patients")
        layout.addWidget(self.patients_table, 1)
        return page

    def _refresh_patients(self):
        patients = db.get_patient_medecins(self.medecin['id']) or []
        data = []
        for p in patients:
            data.append([f"{p.get('prenom','')} {p.get('nom','')}", p.get('numero_dossier',''),
                         p.get('date_naissance',''), p.get('telephone',''), p.get('statut','')])
        self.patients_table.set_data(data)

    def _request_association(self):
        pid = self.assoc_patient_input.text().strip()
        if not pid:
            QMessageBox.warning(self, "Erreur", "Entrez l'ID ou le numero de dossier du patient.")
            return
        patient = self.patient_cache.get(pid)
        if not patient:
            QMessageBox.critical(self, "Erreur", "Patient introuvable. Verifiez l'ID ou le N dossier.")
            return
        try:
            link_id, code = db.create_link(patient['id'], self.medecin['id'])
            db.log_action(self.user['id'], "medecin", "REQUEST_ASSOCIATION", "patient_medecin_links", link_id)
            self.assoc_code_label.setText(f"Code: {code}")
            self.assoc_patient_input.clear()
            QMessageBox.information(self, "Association",
                f"Code d'association genere avec succes.\n\nCode: {code}\n\nDonnez ce code au patient pour qu'il valide l'association.")
        except Exception as e:
            QMessageBox.critical(self, "Erreur", str(e))

    def _build_consultations(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)

        title_row = QWidget()
        trl = QHBoxLayout(title_row)
        trl.setContentsMargins(0, 0, 0, 8)
        t = QLabel("\U0001F4CB  Consultations")
        t.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {C_TEXT};")
        trl.addWidget(t)
        trl.addStretch()
        btn_new = make_btn("Nouvelle consultation", "success", "\u2795")
        btn_new.clicked.connect(self._new_consultation)
        trl.addWidget(btn_new)
        layout.addWidget(title_row)

        self.consults_table = TableWithEmpty(["Patient", "Date", "Heure", "Motif", "Diagnostic", "Statut"], "consultations")
        layout.addWidget(self.consults_table, 1)
        return page

    def _refresh_consultations(self):
        consults = db.get_consultations_by_medecin(self.medecin['id']) or []
        data = []
        for c in consults:
            data.append([f"{c.get('patient_prenom','')} {c.get('patient_nom','')}",
                         c.get('date_consultation',''), c.get('heure_consultation',''),
                         c.get('motif',''), c.get('diagnostic',''), c.get('statut','')])
        self.consults_table.set_data(data)

    def _new_consultation(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Nouvelle consultation")
        dialog.setMinimumWidth(550)
        dialog.setStyleSheet(f"QDialog {{ background: {C_WHITE}; }}")
        layout = QFormLayout(dialog)
        layout.setSpacing(12)
        layout.setContentsMargins(24, 20, 24, 20)

        patient_id_input = QLineEdit(); patient_id_input.setPlaceholderText("ID du patient")
        date_c = QDateEdit(); date_c.setCalendarPopup(True); date_c.setDate(QDate.currentDate())
        heure_c = QTimeEdit(); heure_c.setTime(QTime.currentTime())
        motif = QTextEdit(); motif.setMaximumHeight(60)
        symptomes = QTextEdit(); symptomes.setMaximumHeight(60)
        diagnostic = QTextEdit(); diagnostic.setMaximumHeight(60)
        observations = QTextEdit(); observations.setMaximumHeight(60)
        traitement = QTextEdit(); traitement.setMaximumHeight(60)

        layout.addRow("Patient ID:", patient_id_input)
        layout.addRow("Date:", date_c)
        layout.addRow("Heure:", heure_c)
        layout.addRow("Motif:", motif)
        layout.addRow("Symptomes:", symptomes)
        layout.addRow("Diagnostic:", diagnostic)
        layout.addRow("Observations:", observations)
        layout.addRow("Traitement:", traitement)

        btn_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btn_box.accepted.connect(dialog.accept)
        btn_box.rejected.connect(dialog.reject)
        layout.addRow(btn_box)

        if dialog.exec() == QDialog.Accepted:
            pid = patient_id_input.text().strip()
            if not pid or not motif.toPlainText().strip():
                QMessageBox.warning(self, "Erreur", "Patient ID et motif requis.")
                return
            patient = self.patient_cache.get(pid)
            if not patient:
                QMessageBox.critical(self, "Erreur", "Patient introuvable.")
                return
            db.create_consultation(patient['id'], self.medecin['id'],
                date_c.date().toString("yyyy-MM-dd"), heure_c.time().toString("HH:mm"),
                motif.toPlainText().strip(), symptomes.toPlainText().strip() or None,
                diagnostic.toPlainText().strip() or None, observations.toPlainText().strip() or None,
                traitement.toPlainText().strip() or None)
            db.log_action(self.user['id'], "medecin", "CREATE_CONSULTATION", "consultations",
                         details=f"patient_id={patient['id']}")
            self._refresh_consultations()
            self._show_toast("Consultation creee avec succes", "success")

    def _build_rendezvous(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)

        title_row = QWidget()
        trl = QHBoxLayout(title_row)
        trl.setContentsMargins(0, 0, 0, 8)
        t = QLabel("\U0001F4C5  Rendez-vous")
        t.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {C_TEXT};")
        trl.addWidget(t)
        trl.addStretch()
        btn_new = make_btn("Nouveau RDV", "primary", "\u2795")
        btn_new.clicked.connect(self._new_rdv)
        btn_opt = make_btn("Optimiser (Glouton)", "success", "\U0001F4CA")
        btn_opt.clicked.connect(self._optimize_rdv)
        trl.addWidget(btn_new)
        trl.addWidget(btn_opt)
        self.optimize_result = QLabel("")
        self.optimize_result.setStyleSheet(f"color: {C_SUCCESS}; font-weight: 600;")
        trl.addWidget(self.optimize_result, 1)
        layout.addWidget(title_row)

        self.rdv_table = TableWithEmpty(["Patient", "Date", "Heure", "Motif", "Type", "Priorite", "Statut"], "rdv")
        layout.addWidget(self.rdv_table, 1)
        return page

    def _refresh_rdv(self):
        rdvs = db.get_rendezvous_by_medecin(self.medecin['id']) or []
        data = []
        for rdv in rdvs:
            patient = self.patient_cache.get(str(rdv.get('patient_id','')))
            nom = f"{patient.get('prenom','')} {patient.get('nom','')}" if patient else f"Patient #{rdv.get('patient_id','')}"
            data.append([nom, rdv.get('date_rdv',''), f"{rdv.get('heure_debut','')} - {rdv.get('heure_fin','')}",
                         rdv.get('motif',''), rdv.get('type',''), str(rdv.get('priorite','')), rdv.get('statut','')])
        self.rdv_table.set_data(data)

    def _new_rdv(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Nouveau rendez-vous")
        dialog.setMinimumWidth(480)
        dialog.setStyleSheet(f"QDialog {{ background: {C_WHITE}; }}")
        layout = QFormLayout(dialog)
        layout.setSpacing(12)
        layout.setContentsMargins(24, 20, 24, 20)

        pid_input = QLineEdit(); pid_input.setPlaceholderText("ID du patient")
        date_rdv = QDateEdit(); date_rdv.setCalendarPopup(True); date_rdv.setDate(QDate.currentDate())
        heure_deb = QTimeEdit(); heure_deb.setTime(QTime(9, 0))
        heure_fin = QTimeEdit(); heure_fin.setTime(QTime(9, 30))
        motif = QTextEdit(); motif.setMaximumHeight(60)
        type_rdv = QComboBox(); type_rdv.addItems(["consultation", "suivi", "urgence", "examen", "vaccination"])
        priorite = QComboBox(); priorite.addItems(["1 - Normal", "2 - Urgent", "3 - Critique"])

        layout.addRow("Patient ID:", pid_input)
        layout.addRow("Date:", date_rdv)
        layout.addRow("Heure debut:", heure_deb)
        layout.addRow("Heure fin:", heure_fin)
        layout.addRow("Motif:", motif)
        layout.addRow("Type:", type_rdv)
        layout.addRow("Priorite:", priorite)

        btn_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btn_box.accepted.connect(dialog.accept)
        btn_box.rejected.connect(dialog.reject)
        layout.addRow(btn_box)

        if dialog.exec() == QDialog.Accepted:
            pid = pid_input.text().strip()
            if not pid or not motif.toPlainText().strip():
                QMessageBox.warning(self, "Erreur", "Patient ID et motif requis.")
                return
            patient = self.patient_cache.get(pid)
            if not patient:
                QMessageBox.critical(self, "Erreur", "Patient introuvable.")
                return
            prio = int(priorite.currentText()[0])
            db.create_rendezvous(patient['id'], self.medecin['id'],
                date_rdv.date().toString("yyyy-MM-dd"), heure_deb.time().toString("HH:mm"),
                heure_fin.time().toString("HH:mm"), motif.toPlainText().strip(),
                type_rdv.currentText(), prio)
            db.log_action(self.user['id'], "medecin", "CREATE_RDV", "rendez_vous",
                         details=f"patient_id={patient['id']}")
            self._refresh_rdv()
            self._show_toast("Rendez-vous cree avec succes", "success")

    def _optimize_rdv(self):
        rdvs = db.get_rendezvous_by_medecin(self.medecin['id']) or []
        rdvs_today = [r for r in rdvs if r.get('date_rdv') == date.today().isoformat()]
        if not rdvs_today:
            QMessageBox.information(self, "Optimisation", "Aucun rendez-vous aujourd'hui.")
            return
        appointments = []
        for r in rdvs_today:
            patient = self.patient_cache.get(str(r.get('patient_id','')))
            nom = f"{patient.get('prenom','')} {patient.get('nom','')}" if patient else ""
            appointments.append(Appointment(
                id=r['id'], heure_debut=r.get('heure_debut',''),
                heure_fin=r.get('heure_fin',''), priorite=r.get('priorite',1),
                motif=r.get('motif',''), patient_nom=nom
            ))
        selected, conflicts = greedy_schedule_optimization(appointments)
        total = len(rdvs_today)
        opt = len(selected)
        nb_conflicts = len(conflicts)
        msg = f"Optimisation gloutonne: {opt}/{total} planifiables"
        if nb_conflicts > 0:
            msg += f" | {nb_conflicts} conflit(s)"
        self.optimize_result.setText(msg)
        QMessageBox.information(self, "Optimisation gloutonne",
            f"Rendez-vous aujourd'hui: {total}\n"
            f"Planifiables sans conflit: {opt}\n"
            f"Conflits: {nb_conflicts}\n\n"
            f"Tri par priorite puis selection sans chevauchement.")

    def _build_prescriptions(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)

        title_row = QWidget()
        trl = QHBoxLayout(title_row)
        trl.setContentsMargins(0, 0, 0, 8)
        t = QLabel("\U0001F48A  Prescriptions")
        t.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {C_TEXT};")
        trl.addWidget(t)
        trl.addStretch()
        btn_new = make_btn("Nouvelle prescription", "success", "\u2795")
        btn_new.clicked.connect(self._new_prescription)
        btn_opt = make_btn("Optimiser (DP)", "primary", "\U0001F4CA")
        btn_opt.clicked.connect(self._optimize_presc)
        trl.addWidget(btn_new)
        trl.addWidget(btn_opt)
        layout.addWidget(title_row)

        self.presc_table = TableWithEmpty(["Patient", "Titre", "Contenu", "Date debut", "Date fin", "Statut"], "prescriptions")
        layout.addWidget(self.presc_table, 1)
        return page

    def _refresh_prescriptions(self):
        prescs = db.get_prescriptions_by_medecin(self.medecin['id']) or []
        data = []
        for p in prescs:
            data.append([f"{p.get('patient_prenom','')} {p.get('patient_nom','')}",
                         p.get('titre',''), p.get('contenu',''),
                         p.get('date_debut',''), p.get('date_fin',''), p.get('statut','')])
        self.presc_table.set_data(data)

    def _new_prescription(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Nouvelle prescription")
        dialog.setMinimumWidth(550)
        dialog.setStyleSheet(f"QDialog {{ background: {C_WHITE}; }}")
        layout = QFormLayout(dialog)
        layout.setSpacing(12)
        layout.setContentsMargins(24, 20, 24, 20)

        pid_input = QLineEdit(); pid_input.setPlaceholderText("ID du patient")
        titre = QLineEdit(); titre.setPlaceholderText("Titre de la prescription")
        contenu = QTextEdit(); contenu.setMaximumHeight(80)
        instructions = QTextEdit(); instructions.setMaximumHeight(60)
        date_deb = QDateEdit(); date_deb.setCalendarPopup(True); date_deb.setDate(QDate.currentDate())
        date_fin = QDateEdit(); date_fin.setCalendarPopup(True); date_fin.setDate(QDate.currentDate().addDays(30))

        layout.addRow("Patient ID:", pid_input)
        layout.addRow("Titre:", titre)
        layout.addRow("Contenu:", contenu)
        layout.addRow("Instructions:", instructions)
        layout.addRow("Date debut:", date_deb)
        layout.addRow("Date fin:", date_fin)

        btn_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btn_box.accepted.connect(dialog.accept)
        btn_box.rejected.connect(dialog.reject)
        layout.addRow(btn_box)

        if dialog.exec() == QDialog.Accepted:
            pid = pid_input.text().strip()
            if not pid or not titre.text().strip() or not contenu.toPlainText().strip():
                QMessageBox.warning(self, "Erreur", "Champs obligatoires manquants.")
                return
            patient = self.patient_cache.get(pid)
            if not patient:
                QMessageBox.critical(self, "Erreur", "Patient introuvable.")
                return
            db.create_prescription(0, patient['id'], self.medecin['id'],
                titre.text().strip(), contenu.toPlainText().strip(),
                instructions=instructions.toPlainText().strip() or None,
                date_debut=date_deb.date().toString("yyyy-MM-dd"),
                date_fin=date_fin.date().toString("yyyy-MM-dd"))
            db.log_action(self.user['id'], "medecin", "CREATE_PRESCRIPTION", "prescriptions",
                         details=f"patient_id={patient['id']}, titre={titre.text()}")
            self._refresh_prescriptions()
            self._show_toast("Prescription creee avec succes", "success")

    def _optimize_presc(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Optimisation DP des prescriptions")
        dialog.setMinimumWidth(550)
        dialog.setStyleSheet(f"QDialog {{ background: {C_WHITE}; }}")
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(12)

        layout.addWidget(QLabel("Programmation dynamique - Sac a dos 0/1"))
        layout.addWidget(QLabel("Ajoutez des medicaments avec leur cout et efficacite:"))

        med_list = QWidget()
        med_layout = QVBoxLayout(med_list)
        med_entries = []

        def add_med_entry(nom="", cout=0, efficacite=0, duree=30):
            row = QWidget()
            rl = QHBoxLayout(row)
            rl.setContentsMargins(0, 2, 0, 2)
            e_nom = QLineEdit(nom); e_nom.setPlaceholderText("Medicament")
            e_cout = QDoubleSpinBox(); e_cout.setRange(0, 10000); e_cout.setValue(cout); e_cout.setPrefix("Ar ")
            e_eff = QSpinBox(); e_eff.setRange(0, 100); e_eff.setValue(efficacite)
            e_dur = QSpinBox(); e_dur.setRange(1, 365); e_dur.setValue(duree)
            rl.addWidget(e_nom, 2); rl.addWidget(QLabel("Cout:")); rl.addWidget(e_cout)
            rl.addWidget(QLabel("Eff:")); rl.addWidget(e_eff); rl.addWidget(QLabel("Jrs:")); rl.addWidget(e_dur)
            med_layout.addWidget(row)
            med_entries.append((e_nom, e_cout, e_eff, e_dur))

        add_med_entry("Paracetamol", 5, 7, 30)
        add_med_entry("Ibuprofene", 8, 9, 15)
        add_med_entry("Amoxicilline", 15, 10, 7)
        add_med_entry("Vitamine C", 3, 4, 30)
        add_med_entry("Omeprazole", 12, 8, 30)

        scroll = QScrollArea()
        scroll.setWidget(med_list)
        scroll.setWidgetResizable(True)
        scroll.setMaximumHeight(250)
        layout.addWidget(scroll)

        budget_w = QWidget()
        bl = QHBoxLayout(budget_w)
        budget_spin = QDoubleSpinBox(); budget_spin.setRange(1, 100000); budget_spin.setValue(30); budget_spin.setPrefix("Ar ")
        bl.addWidget(QLabel("Budget max:")); bl.addWidget(budget_spin); bl.addStretch()
        layout.addWidget(budget_w)

        result_area = QTextEdit()
        result_area.setReadOnly(True)
        result_area.setMaximumHeight(140)
        result_area.setStyleSheet(f"background: {C_PRIMARY_LIGHT}; border: 2px solid {C_PRIMARY}; border-radius: 12px; padding: 8px;")
        layout.addWidget(result_area)

        btn_calc = make_btn("Optimiser (DP Sac a dos)", "primary", "\U0001F4CA")
        btn_calc.clicked.connect(lambda: self._run_dp_optimization(med_entries, budget_spin, result_area))
        layout.addWidget(btn_calc)

        btn_close = QPushButton("Fermer")
        btn_close.setObjectName("btnOutline")
        btn_close.clicked.connect(dialog.accept)
        layout.addWidget(btn_close)

        dialog.exec()

    def _run_dp_optimization(self, entries, budget_spin, result_area):
        medicaments = []
        for e_nom, e_cout, e_eff, e_dur in entries:
            nom = e_nom.text().strip()
            if nom:
                medicaments.append(Medicament(nom, e_cout.value(), e_eff.value(), e_dur.value()))
        if not medicaments:
            QMessageBox.warning(self, "Erreur", "Ajoutez au moins un medicament.")
            return
        result = optimize_prescriptions_dp(medicaments, budget_spin.value())
        selected = result['selected']
        if not selected:
            result_area.setText("Aucun medicament selectionne dans le budget.")
            return
        lines = ["=== Optimisation DP (Sac a dos) ==="]
        lines.append(f"Budget: Ar {budget_spin.value():.0f}")
        lines.append(f"Medicaments ({len(selected)}):")
        for m in selected:
            lines.append(f"  - {m.nom}: Ar {m.cout:.0f} (eff: {m.efficacite}, {m.duree_jours}j)")
        lines.append(f"Cout: Ar {result['total_cost']:.0f}")
        lines.append(f"Efficacite: {result['total_efficacy']}")
        lines.append(f"Budget utilise: {result['budget_used']:.0f}%")
        lines.append(f"Complexite: O(n x W)")
        result_area.setText("\n".join(lines))

    def _build_recherche(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)

        title = QLabel("\U0001F50D  Recherche Médicale")
        title.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {C_TEXT}; margin-bottom: 6px;")
        layout.addWidget(title)

        subtitle = QLabel("Trouvez rapidement une consultation en explorant l'historique de vos patients.")
        subtitle.setStyleSheet(f"color: {C_TEXT_SEC}; font-size: 13px; margin-bottom: 18px;")
        layout.addWidget(subtitle)

        search_bar = QWidget()
        sl = QHBoxLayout(search_bar)
        sl.setContentsMargins(0, 0, 0, 12)
        self.kmp_search_input = QLineEdit()
        self.kmp_search_input.setPlaceholderText("Motif, diagnostic, symptômes...")
        self.kmp_search_input.returnPressed.connect(self._kmp_search)
        btn_search = make_btn("Rechercher", "primary", "\U0001F50D")
        btn_search.clicked.connect(self._kmp_search)
        sl.addWidget(self.kmp_search_input, 1)
        sl.addWidget(btn_search)
        layout.addWidget(search_bar)

        self.kmp_result_label = QLabel("Entrez un terme de recherche pour afficher les résultats.")
        self.kmp_result_label.setStyleSheet(f"color: {C_TEXT_SEC}; font-size: 13px; margin-bottom: 12px;")
        layout.addWidget(self.kmp_result_label)

        self.kmp_table = TableWithEmpty(["Patient", "Date", "Heure", "Motif", "Diagnostic", "Observations", "Traitement"], "default")
        layout.addWidget(self.kmp_table, 1)
        return page

    def _kmp_search(self):
        query = self.kmp_search_input.text().strip()
        if not query:
            QMessageBox.warning(self, "Recherche", "Entrez un terme de recherche.")
            return
        patients = db.get_patient_medecins(self.medecin['id']) or []
        all_results = []
        for pat in patients:
            consults = db.get_consultations_by_patient(pat['id']) or []
            results = search_medical_history(consults, query)
            for r in results:
                r['_patient_name'] = f"{pat.get('prenom','')} {pat.get('nom','')}"
                all_results.append(r)
        data = []
        for c in all_results:
            data.append([c.get('_patient_name',''), c.get('date_consultation',''),
                         c.get('heure_consultation',''), c.get('motif',''),
                         c.get('diagnostic',''), c.get('observations',''), c.get('traitement','')])
        self.kmp_table.set_data(data)
        self.kmp_result_label.setText(f"{len(all_results)} résultat(s) trouvés")

    def _show_toast(self, message, type="success"):
        toast = ToastNotification(self.content_stack, message, type)
        toast.show()
        pw = self.content_stack.width()
        toast.setGeometry(pw - 370, 16, 350, 52)

# ============================================================
# FENETRE ADMIN
# ============================================================
class AdminWindow(QMainWindow):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.setWindowTitle("Administration - MediCare Santé")
        self.setMinimumSize(1200, 750)
        self.setStyleSheet(STYLE_BASE)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(28, 28, 28, 28)

        header = QWidget()
        hl = QHBoxLayout(header)
        hl.setContentsMargins(0, 0, 0, 16)
        titre = QLabel("\U0001F6E1\uFE0F  Administration")
        titre.setStyleSheet(f"font-size: 22px; font-weight: 700; color: {C_TEXT};")
        hl.addWidget(titre)
        hl.addStretch()
        btn_logout = make_btn("Deconnexion", "danger", "\U0001F6AA")
        btn_logout.clicked.connect(self._logout)
        hl.addWidget(btn_logout)
        layout.addWidget(header)

        self.tabs = QTabWidget()
        self.tabs.setStyleSheet(f"""
            QTabBar::tab {{ padding: 12px 24px; font-size: 13px; font-weight: 500; }}
            QTabBar::tab:selected {{ background: {C_PRIMARY}; color: white; border-radius: 6px 6px 0 0; font-weight: 700; }}
            QTabBar::tab:hover:!selected {{ background: {C_PRIMARY_LIGHT}; }}
        """)
        self.tabs.addTab(self._build_medecins_tab(), "Valider Medecins")
        self.tabs.addTab(self._build_users_tab(), "Utilisateurs")
        self.tabs.addTab(self._build_audit_tab(), "Journal d'Audit")
        self.tabs.addTab(self._build_stats_tab(), "Statistiques")
        layout.addWidget(self.tabs, 1)

    def _build_medecins_tab(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(20, 20, 20, 20)

        self.medecins_table = TableWithEmpty(["ID", "Nom", "Prenom", "Specialite", "N Ordre", "Email", "Telephone", "Statut", "Action"], "default")
        layout.addWidget(self.medecins_table, 1)

        btn_refresh = make_btn("Actualiser", "outline", "\U0001F504")
        btn_refresh.clicked.connect(self._load_medecins)
        layout.addWidget(btn_refresh)

        self._load_medecins()
        return page

    def _load_medecins(self):
        medecins = db.get_medecin() or []
        data = []
        for m in medecins:
            data.append([str(m.get('id','')), m.get('nom',''), m.get('prenom',''), m.get('specialite',''),
                         m.get('numero_ordre',''), m.get('telephone',''), m.get('email','') or '',
                         m.get('statut',''), ""])
        self.medecins_table.set_data(data)
        for r, m in enumerate(medecins):
            if m.get('statut') == 'en_attente':
                actions = QWidget()
                al = QHBoxLayout(actions)
                al.setContentsMargins(2, 2, 2, 2)
                al.setSpacing(6)
                btn_val = make_btn("Valider", "success", "\u2705")
                btn_val.clicked.connect(lambda checked, mid=m['id']: self._verify_medecin(mid, "verifie"))
                btn_rej = make_btn("Rejeter", "danger", "\u274C")
                btn_rej.clicked.connect(lambda checked, mid=m['id']: self._verify_medecin(mid, "rejete"))
                al.addWidget(btn_val)
                al.addWidget(btn_rej)
                self.medecins_table.table.setCellWidget(r, 8, actions)
            elif m.get('statut') == 'verifie':
                btn_sus = make_btn("Suspendre", "warning", "\u26D4")
                btn_sus.clicked.connect(lambda checked, mid=m['id']: self._verify_medecin(mid, "suspendu"))
                self.medecins_table.table.setCellWidget(r, 8, btn_sus)
            elif m.get('statut') == 'suspendu':
                btn_react = make_btn("Reactivier", "success", "\u267B")
                btn_react.clicked.connect(lambda checked, mid=m['id']: self._verify_medecin(mid, "verifie"))
                self.medecins_table.table.setCellWidget(r, 8, btn_react)

    def _verify_medecin(self, medecin_id, statut):
        db._execute("UPDATE medecins SET statut=?, date_verification=?, verifie_par=? WHERE id=?",
                   (statut, datetime.now().isoformat(), self.user['id'], medecin_id), commit=True)
        db.log_action(self.user['id'], "admin", f"MEDECIN_{statut.upper()}", "medecins", medecin_id)
        self._load_medecins()
        status_map = {"verifie": "valide", "rejete": "rejete", "suspendu": "suspendu"}
        self._show_toast(f"Medecin {status_map.get(statut, statut)} avec succes", "success" if statut != "rejete" else "warning")

    def _build_users_tab(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(20, 20, 20, 20)

        self.users_table = TableWithEmpty(["ID", "Email", "Role", "Nom", "Prenom", "Actif", "Actions"], "default")
        layout.addWidget(self.users_table, 1)

        btn_refresh = make_btn("Actualiser", "outline", "\U0001F504")
        btn_refresh.clicked.connect(self._load_users)
        layout.addWidget(btn_refresh)

        self._load_users()
        return page

    def _load_users(self):
        users = db._execute("SELECT * FROM users ORDER BY created_at DESC", (), fetchall=True) or []
        data = []
        for u in users:
            data.append([str(u.get('id','')), u.get('email',''), u.get('role',''),
                         u.get('nom',''), u.get('prenom',''), "Oui" if u.get('est_actif', 1) else "Non", ""])
        self.users_table.set_data(data)
        for r, u in enumerate(users):
            actions = QWidget()
            al = QHBoxLayout(actions)
            al.setContentsMargins(2, 2, 2, 2)
            al.setSpacing(4)
            if u.get('est_actif', 1):
                btn_sus = make_btn("Suspendre", "warning", "\u26D4")
            else:
                btn_sus = make_btn("Reactivier", "success", "\u267B")
            btn_sus.clicked.connect(lambda checked, uid=u['id'], actif=u.get('est_actif', 1):
                self._toggle_user_status(uid, not actif))
            btn_del = make_btn("Suppr.", "danger", "\u274C")
            btn_del.clicked.connect(lambda checked, uid=u['id'], email=u.get('email',''):
                self._delete_user(uid, email))
            al.addWidget(btn_sus)
            if u.get('role') != 'admin':
                al.addWidget(btn_del)
            self.users_table.table.setCellWidget(r, 6, actions)

    def _toggle_user_status(self, user_id, actif):
        db._execute("UPDATE users SET est_actif=? WHERE id=?", (1 if actif else 0, user_id), commit=True)
        db.log_action(self.user['id'], "admin", "TOGGLE_USER_STATUS", "users", user_id, details=f"actif={actif}")
        self._load_users()

    def _delete_user(self, user_id, email):
        if QMessageBox.question(self, "Confirmation",
                f"Supprimer l'utilisateur {email} (ID: {user_id}) ?\nCette action est irreversible.",
                QMessageBox.Yes|QMessageBox.No) == QMessageBox.Yes:
            db._execute("DELETE FROM patients WHERE user_id=?", (user_id,), commit=True)
            db._execute("DELETE FROM medecins WHERE user_id=?", (user_id,), commit=True)
            db._execute("DELETE FROM users WHERE id=?", (user_id,), commit=True)
            db.log_action(self.user['id'], "admin", "DELETE_USER", "users", user_id, details=f"email={email}")
            self._load_users()
            self._show_toast(f"Utilisateur {email} supprime", "success")

    def _build_audit_tab(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(20, 20, 20, 20)

        self.audit_table = TableWithEmpty(["Date", "Utilisateur", "Role", "Action", "Entite", "Details", "Statut"], "default")
        layout.addWidget(self.audit_table, 1)

        btn_refresh = make_btn("Actualiser", "outline", "\U0001F504")
        btn_refresh.clicked.connect(self._load_audit)
        layout.addWidget(btn_refresh)

        self._load_audit()
        return page

    def _load_audit(self):
        logs = db._execute("SELECT * FROM audit_log ORDER BY created_at DESC LIMIT 200", (), fetchall=True) or []
        data = []
        for log in logs:
            s = log.get('statut','')
            data.append([log.get('created_at',''), str(log.get('user_id','')),
                         log.get('user_role',''), log.get('action',''),
                         f"{log.get('entite','')} #{log.get('entite_id','')}", log.get('details',''), s])
        self.audit_table.set_data(data)
        for r, log in enumerate(logs):
            s = log.get('statut','')
            if s == 'echec':
                item = self.audit_table.table.item(r, 6)
                if item:
                    item.setForeground(QColor(C_DANGER))

    def _build_stats_tab(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(20, 20, 20, 20)

        stats = QWidget()
        sl = QGridLayout(stats)
        sl.setSpacing(16)

        count_queries = [
            ("\U0001F465 Utilisateurs", "SELECT COUNT(*) as c FROM users"),
            ("\U0001F468 Patients", "SELECT COUNT(*) as c FROM patients"),
            ("\U0001FA7A Medecins", "SELECT COUNT(*) as c FROM medecins"),
            ("\u23F3 En attente", "SELECT COUNT(*) as c FROM medecins WHERE statut='en_attente'"),
            ("\U0001F4CB Consultations", "SELECT COUNT(*) as c FROM consultations"),
            ("\U0001F48A Prescriptions", "SELECT COUNT(*) as c FROM prescriptions"),
            ("\U0001F4C5 Rendez-vous", "SELECT COUNT(*) as c FROM rendez_vous"),
            ("\u26A0 Allergies", "SELECT COUNT(*) as c FROM allergies"),
            ("\U0001F52C Examens", "SELECT COUNT(*) as c FROM examens"),
            ("\U0001F4DD Actions", "SELECT COUNT(*) as c FROM audit_log"),
        ]
        colors = [C_PRIMARY, C_SUCCESS, "#8B5CF6", C_WARNING, C_DANGER, "#EC4899", "#14B8A6", "#F97316", "#6366F1", "#84CC16"]

        for i, (label, query) in enumerate(count_queries):
            row = i // 2
            col = i % 2
            try:
                result = db._execute(query, (), fetchone=True)
                count = result.get('c', 0) if result else 0
            except:
                count = 0
            sl.addWidget(StatCard(label, count, colors[i % len(colors)]), row, col)

        layout.addWidget(stats)
        layout.addStretch()
        return page

    def _logout(self):
        db.log_action(self.user['id'], "admin", "LOGOUT", "users", self.user['id'])
        self.login = LoginWindow()
        self.login.show()
        self.close()

    def _show_toast(self, message, type="success"):
        toast = ToastNotification(self.tabs, message, type)
        toast.show()
        tw = self.tabs.width()
        toast.setGeometry(tw - 370, 8, 350, 52)

# ============================================================
# SEED & ENTRY POINT
# ============================================================
def seed_demo_data():
    count = db._execute("SELECT COUNT(*) as c FROM users", (), fetchone=True)
    if count and count.get('c', 0) > 0:
        return
    print("Seed: Ajout des donnees de demonstration...")

    admin_id = db.create_user("admin@carnetmed.mg", "admin123", "admin", "Admin", "Systeme")
    db.log_action(admin_id, "admin", "SEED", "system", details="Seed automatique")

    pat_user_id = db.create_user("patient@exemple.mg", "patient123", "patient", "Rakoto", "Jean", "0341234567")
    db.create_patient(pat_user_id, "Rakoto", "Jean", "1990-05-15", "M",
                     adresse="Antananarivo", groupe_sanguin="O+", taille_cm=175, poids_kg="70")

    med_user_id = db.create_user("medecin@exemple.mg", "medecin123", "medecin", "Rasoa", "Marie", "0347654321")
    db.create_medecin(med_user_id, "MG-2024-001", "Rasoa", "Marie", "Cardiologie",
                     "CHU Antananarivo", "0347654321", "medecin@exemple.mg", statut="verifie", verifie_par=admin_id)

    pat = db._execute("SELECT id FROM patients WHERE user_id=?", (pat_user_id,), fetchone=True)
    med = db._execute("SELECT id FROM medecins WHERE user_id=?", (med_user_id,), fetchone=True)
    pat_id = pat['id'] if pat else None
    med_id = med['id'] if med else None

    if pat_id and med_id:
        db.create_link(pat_id, med_id, "LINK-2024-001")
        db.validate_link("LINK-2024-001", pat_id)
        db.create_consultation(pat_id, med_id, "2024-06-15", "09:30", "Consultation de routine",
                              "Toux seche, fievre legere", "Rhinite allergique",
                              "Prescrire antihistaminique", "Cetirizine 10mg/jour")
        db.create_prescription(1, pat_id, med_id, "Antihistaminique", "Cetirizine 10mg",
                              date_debut="2024-06-15", date_fin="2024-07-15")
        db.create_rendezvous(pat_id, med_id, "2024-07-15", "10:00", "10:30",
                            "Suivi mensuel", "suivi", 2)
        db.create_allergie(pat_id, "Penicilline", "severe",
                          "Reaction cutanee severe, necessite hospitalisation", "2018-03-10")
        db.create_examen(pat_id, 1, med_id, "Prise de sang",
                        "Globules blancs: 7500/mm3\nHemoglobine: 14g/dL",
                        date_examen="2024-06-15")

    db.log_action(admin_id, "admin", "SEED_COMPLETE", "system", details="Donnees de demo inserees")
    print("Seed: Donnees de demonstration ajoutees avec succes.")


def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(STYLE_BASE)
    db.init_db()
    seed_demo_data()
    window = LoginWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
